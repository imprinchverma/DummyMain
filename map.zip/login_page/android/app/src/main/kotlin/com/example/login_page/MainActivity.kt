package com.example.login_page

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
